from rest_framework import serializers 
from .models import Bme280
 
 
class Bme280Serializer(serializers.ModelSerializer):
 
    class Meta:
        model = Bme280
        fields = ('timestampmesure',
                  'creele',
                  'temperature',
                  'humidity',
                  'pression')

