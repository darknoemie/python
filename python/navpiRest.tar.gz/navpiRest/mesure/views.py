from django.shortcuts import render 
from django.http import HttpResponse
from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser 
from rest_framework import status
 
from .models import Bme280
from .serializers import Bme280Serializer
 
@csrf_exempt
def bme280_list(request):
    if request.method == 'GET':
        bme280 = Bme280.objects.all()
        bme280_serializer = Bme280Serializer(bme280, many=True)
        return JsonResponse(bme280_serializer.data, safe=False)
        # In order to serialize objects, we must set 'safe=False'
 
    elif request.method == 'POST':
        bme280_data = JSONParser().parse(request)
        bme280_serializer = Bme280Serializer(data=bme280_data)
        if bme280_serializer.is_valid():
            bme280_serializer.save() 
            return JsonResponse(bme280_serializer.data, status=status.HTTP_201_CREATED) 
        return JsonResponse(bme280_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
 
 
@csrf_exempt 
def bme280_detail(request, pk):
    try: 
        bme280 = Bme280.objects.get(pk=pk) 
    except Bme280.DoesNotExist: 
        return HttpResponse(status=status.HTTP_404_NOT_FOUND) 
 
    if request.method == 'GET': 
        bme280_serializer = Bme280Serializer(bme280) 
        return JsonResponse(bme280_serializer.data) 
 
    elif request.method == 'PUT': 
        bme280_data = JSONParser().parse(request) 
        bme280_serializer = Bme280Serializer(bme280, data=bme280_data) 
        if bme280_serializer.is_valid(): 
            bme280_serializer.save() 
            return JsonResponse(bme280_serializer.data) 
        return JsonResponse(bme280_serializer.errors, status=status.HTTP_400_BAD_REQUEST) 
 
    elif request.method == 'DELETE': 
        bme280.delete() 
        return HttpResponse(status=status.HTTP_204_NO_CONTENT)