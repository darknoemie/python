from django.apps import AppConfig

class MesureConfig(AppConfig):
    name = 'mesure'