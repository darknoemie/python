from django.conf.urls import url 
from . import views 
 
urlpatterns = [ 
    url(r'^bme280/$', views.bme280_list),
    url(r'^bme280/(?P<pk>[0-9T:-]+)$', views.bme280_detail),
]